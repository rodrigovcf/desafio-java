package com.desafiojava.entities;

public class Turma {

}
